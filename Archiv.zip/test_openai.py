from sentiment.openai_analyzer import analyze_with_openai

result = analyze_with_openai("I’m feeling very anxious and a bit sad.")
print(result)
